TAKEMY POSSUM WEBSITE — STARTER PACKAGE

Files:
- index.html: complete responsive website (HTML, CSS and JavaScript in one file).

IMPORTANT BEFORE PUBLISHING:
1. Open index.html and replace YOUR-BUSINESS-EMAIL@example.com in the script with your real business email.
2. Add your real phone number where the contact section says to add it.
3. Confirm the services you are legally authorised and qualified to provide in Victoria. In particular, possum handling/relocation is regulated wildlife work and must only be advertised/performed in accordance with current Victorian requirements.
4. The enquiry form currently opens the visitor's email app. It does not store submissions or send them to a server. For a true online form, connect a free form service later.
5. The site has not been published and the GoDaddy domain is not yet connected.

FREE HOSTING OPTION:
GitHub Pages can host a static website for free. Create a GitHub repository, upload index.html, enable Pages in repository Settings > Pages, then configure the custom domain in GitHub Pages and add the DNS records GitHub specifies in GoDaddy. DNS changes can take time to propagate. Do not change DNS until GitHub provides the exact records for your site.
